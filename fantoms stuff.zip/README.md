![](https://img.shields.io/badge/Foundry-v10.0.0-informational)


# fantoms stuff

Just a personal module, pay no mind.